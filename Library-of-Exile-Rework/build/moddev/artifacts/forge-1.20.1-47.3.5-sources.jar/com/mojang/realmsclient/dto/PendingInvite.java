package com.mojang.realmsclient.dto;

import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.util.JsonUtils;
import java.util.Date;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class PendingInvite extends ValueObject {
   private static final Logger LOGGER = LogUtils.getLogger();
   public String invitationId;
   public String worldName;
   public String worldOwnerName;
   public String worldOwnerUuid;
   public Date date;

   public static PendingInvite parse(JsonObject json) {
      PendingInvite pendinginvite = new PendingInvite();

      try {
         pendinginvite.invitationId = JsonUtils.getStringOr("invitationId", json, "");
         pendinginvite.worldName = JsonUtils.getStringOr("worldName", json, "");
         pendinginvite.worldOwnerName = JsonUtils.getStringOr("worldOwnerName", json, "");
         pendinginvite.worldOwnerUuid = JsonUtils.getStringOr("worldOwnerUuid", json, "");
         pendinginvite.date = JsonUtils.getDateOr("date", json);
      } catch (Exception exception) {
         LOGGER.error("Could not parse PendingInvite: {}", (Object)exception.getMessage());
      }

      return pendinginvite;
   }
}
