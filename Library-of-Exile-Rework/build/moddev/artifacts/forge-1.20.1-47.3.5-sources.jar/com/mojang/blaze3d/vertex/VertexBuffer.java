package com.mojang.blaze3d.vertex;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.systems.RenderSystem;
import java.nio.ByteBuffer;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix4f;

@OnlyIn(Dist.CLIENT)
public class VertexBuffer implements AutoCloseable {
   private final VertexBuffer.Usage usage;
   private int vertexBufferId;
   private int indexBufferId;
   private int arrayObjectId;
   @Nullable
   private VertexFormat format;
   @Nullable
   private RenderSystem.AutoStorageIndexBuffer sequentialIndices;
   private VertexFormat.IndexType indexType;
   private int indexCount;
   private VertexFormat.Mode mode;

   public VertexBuffer(VertexBuffer.Usage usage) {
      this.usage = usage;
      RenderSystem.assertOnRenderThread();
      this.vertexBufferId = GlStateManager._glGenBuffers();
      this.indexBufferId = GlStateManager._glGenBuffers();
      this.arrayObjectId = GlStateManager._glGenVertexArrays();
   }

   public void upload(BufferBuilder.RenderedBuffer buffer) {
      if (!this.isInvalid()) {
         RenderSystem.assertOnRenderThread();

         try {
            BufferBuilder.DrawState bufferbuilder$drawstate = buffer.drawState();
            this.format = this.uploadVertexBuffer(bufferbuilder$drawstate, buffer.vertexBuffer());
            this.sequentialIndices = this.uploadIndexBuffer(bufferbuilder$drawstate, buffer.indexBuffer());
            this.indexCount = bufferbuilder$drawstate.indexCount();
            this.indexType = bufferbuilder$drawstate.indexType();
            this.mode = bufferbuilder$drawstate.mode();
         } finally {
            buffer.release();
         }

      }
   }

   private VertexFormat uploadVertexBuffer(BufferBuilder.DrawState drawState, ByteBuffer buffer) {
      boolean flag = false;
      if (!drawState.format().equals(this.format)) {
         if (this.format != null) {
            this.format.clearBufferState();
         }

         GlStateManager._glBindBuffer(34962, this.vertexBufferId);
         drawState.format().setupBufferState();
         flag = true;
      }

      if (!drawState.indexOnly()) {
         if (!flag) {
            GlStateManager._glBindBuffer(34962, this.vertexBufferId);
         }

         RenderSystem.glBufferData(34962, buffer, this.usage.id);
      }

      return drawState.format();
   }

   @Nullable
   private RenderSystem.AutoStorageIndexBuffer uploadIndexBuffer(BufferBuilder.DrawState drawState, ByteBuffer buffer) {
      if (!drawState.sequentialIndex()) {
         GlStateManager._glBindBuffer(34963, this.indexBufferId);
         RenderSystem.glBufferData(34963, buffer, this.usage.id);
         return null;
      } else {
         RenderSystem.AutoStorageIndexBuffer rendersystem$autostorageindexbuffer = RenderSystem.getSequentialBuffer(drawState.mode());
         if (rendersystem$autostorageindexbuffer != this.sequentialIndices || !rendersystem$autostorageindexbuffer.hasStorage(drawState.indexCount())) {
            rendersystem$autostorageindexbuffer.bind(drawState.indexCount());
         }

         return rendersystem$autostorageindexbuffer;
      }
   }

   public void bind() {
      BufferUploader.invalidate();
      GlStateManager._glBindVertexArray(this.arrayObjectId);
   }

   public static void unbind() {
      BufferUploader.invalidate();
      GlStateManager._glBindVertexArray(0);
   }

   public void draw() {
      RenderSystem.drawElements(this.mode.asGLMode, this.indexCount, this.getIndexType().asGLType);
   }

   private VertexFormat.IndexType getIndexType() {
      RenderSystem.AutoStorageIndexBuffer rendersystem$autostorageindexbuffer = this.sequentialIndices;
      return rendersystem$autostorageindexbuffer != null ? rendersystem$autostorageindexbuffer.type() : this.indexType;
   }

   public void drawWithShader(Matrix4f modelViewMatrix, Matrix4f projectionMatrix, ShaderInstance shader) {
      if (!RenderSystem.isOnRenderThread()) {
         RenderSystem.recordRenderCall(() -> {
            this._drawWithShader(new Matrix4f(modelViewMatrix), new Matrix4f(projectionMatrix), shader);
         });
      } else {
         this._drawWithShader(modelViewMatrix, projectionMatrix, shader);
      }

   }

   private void _drawWithShader(Matrix4f modelViewMatrix, Matrix4f projectionMatrix, ShaderInstance shader) {
      for(int i = 0; i < 12; ++i) {
         int j = RenderSystem.getShaderTexture(i);
         shader.setSampler("Sampler" + i, j);
      }

      if (shader.MODEL_VIEW_MATRIX != null) {
         shader.MODEL_VIEW_MATRIX.set(modelViewMatrix);
      }

      if (shader.PROJECTION_MATRIX != null) {
         shader.PROJECTION_MATRIX.set(projectionMatrix);
      }

      if (shader.INVERSE_VIEW_ROTATION_MATRIX != null) {
         shader.INVERSE_VIEW_ROTATION_MATRIX.set(RenderSystem.getInverseViewRotationMatrix());
      }

      if (shader.COLOR_MODULATOR != null) {
         shader.COLOR_MODULATOR.set(RenderSystem.getShaderColor());
      }

      if (shader.GLINT_ALPHA != null) {
         shader.GLINT_ALPHA.set(RenderSystem.getShaderGlintAlpha());
      }

      if (shader.FOG_START != null) {
         shader.FOG_START.set(RenderSystem.getShaderFogStart());
      }

      if (shader.FOG_END != null) {
         shader.FOG_END.set(RenderSystem.getShaderFogEnd());
      }

      if (shader.FOG_COLOR != null) {
         shader.FOG_COLOR.set(RenderSystem.getShaderFogColor());
      }

      if (shader.FOG_SHAPE != null) {
         shader.FOG_SHAPE.set(RenderSystem.getShaderFogShape().getIndex());
      }

      if (shader.TEXTURE_MATRIX != null) {
         shader.TEXTURE_MATRIX.set(RenderSystem.getTextureMatrix());
      }

      if (shader.GAME_TIME != null) {
         shader.GAME_TIME.set(RenderSystem.getShaderGameTime());
      }

      if (shader.SCREEN_SIZE != null) {
         Window window = Minecraft.getInstance().getWindow();
         shader.SCREEN_SIZE.set((float)window.getWidth(), (float)window.getHeight());
      }

      if (shader.LINE_WIDTH != null && (this.mode == VertexFormat.Mode.LINES || this.mode == VertexFormat.Mode.LINE_STRIP)) {
         shader.LINE_WIDTH.set(RenderSystem.getShaderLineWidth());
      }

      RenderSystem.setupShaderLights(shader);
      shader.apply();
      this.draw();
      shader.clear();
   }

   public void close() {
      if (this.vertexBufferId >= 0) {
         RenderSystem.glDeleteBuffers(this.vertexBufferId);
         this.vertexBufferId = -1;
      }

      if (this.indexBufferId >= 0) {
         RenderSystem.glDeleteBuffers(this.indexBufferId);
         this.indexBufferId = -1;
      }

      if (this.arrayObjectId >= 0) {
         RenderSystem.glDeleteVertexArrays(this.arrayObjectId);
         this.arrayObjectId = -1;
      }

   }

   public VertexFormat getFormat() {
      return this.format;
   }

   public boolean isInvalid() {
      return this.arrayObjectId == -1;
   }

   @OnlyIn(Dist.CLIENT)
   public static enum Usage {
      STATIC(35044),
      DYNAMIC(35048);

      final int id;

      private Usage(int id) {
         this.id = id;
      }
   }
}
