package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;

public class UsedTotemTrigger extends SimpleCriterionTrigger<UsedTotemTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("used_totem");

   public ResourceLocation getId() {
      return ID;
   }

   public UsedTotemTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ItemPredicate itempredicate = ItemPredicate.fromJson(json.get("item"));
      return new UsedTotemTrigger.TriggerInstance(predicate, itempredicate);
   }

   public void trigger(ServerPlayer player, ItemStack item) {
      this.trigger(player, (p_74436_) -> {
         return p_74436_.matches(item);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ItemPredicate item;

      public TriggerInstance(ContextAwarePredicate player, ItemPredicate item) {
         super(UsedTotemTrigger.ID, player);
         this.item = item;
      }

      public static UsedTotemTrigger.TriggerInstance usedTotem(ItemPredicate item) {
         return new UsedTotemTrigger.TriggerInstance(ContextAwarePredicate.ANY, item);
      }

      public static UsedTotemTrigger.TriggerInstance usedTotem(ItemLike item) {
         return new UsedTotemTrigger.TriggerInstance(ContextAwarePredicate.ANY, ItemPredicate.Builder.item().of(item).build());
      }

      public boolean matches(ItemStack item) {
         return this.item.matches(item);
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("item", this.item.serializeToJson());
         return jsonobject;
      }
   }
}
