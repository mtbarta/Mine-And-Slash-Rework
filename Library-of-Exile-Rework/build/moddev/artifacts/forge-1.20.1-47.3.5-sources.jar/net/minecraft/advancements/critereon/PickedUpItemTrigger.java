package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import javax.annotation.Nullable;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;

public class PickedUpItemTrigger extends SimpleCriterionTrigger<PickedUpItemTrigger.TriggerInstance> {
   private final ResourceLocation id;

   public PickedUpItemTrigger(ResourceLocation id) {
      this.id = id;
   }

   public ResourceLocation getId() {
      return this.id;
   }

   protected PickedUpItemTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ItemPredicate itempredicate = ItemPredicate.fromJson(json.get("item"));
      ContextAwarePredicate contextawarepredicate = EntityPredicate.fromJson(json, "entity", deserializationContext);
      return new PickedUpItemTrigger.TriggerInstance(this.id, predicate, itempredicate, contextawarepredicate);
   }

   public void trigger(ServerPlayer player, ItemStack stack, @Nullable Entity entity) {
      LootContext lootcontext = EntityPredicate.createContext(player, entity);
      this.trigger(player, (p_221306_) -> {
         return p_221306_.matches(player, stack, lootcontext);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ItemPredicate item;
      private final ContextAwarePredicate entity;

      public TriggerInstance(ResourceLocation criterion, ContextAwarePredicate player, ItemPredicate item, ContextAwarePredicate entity) {
         super(criterion, player);
         this.item = item;
         this.entity = entity;
      }

      public static PickedUpItemTrigger.TriggerInstance thrownItemPickedUpByEntity(ContextAwarePredicate player, ItemPredicate item, ContextAwarePredicate entity) {
         return new PickedUpItemTrigger.TriggerInstance(CriteriaTriggers.THROWN_ITEM_PICKED_UP_BY_ENTITY.getId(), player, item, entity);
      }

      public static PickedUpItemTrigger.TriggerInstance thrownItemPickedUpByPlayer(ContextAwarePredicate player, ItemPredicate item, ContextAwarePredicate entity) {
         return new PickedUpItemTrigger.TriggerInstance(CriteriaTriggers.THROWN_ITEM_PICKED_UP_BY_PLAYER.getId(), player, item, entity);
      }

      public boolean matches(ServerPlayer player, ItemStack stack, LootContext context) {
         if (!this.item.matches(stack)) {
            return false;
         } else {
            return this.entity.matches(context);
         }
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("item", this.item.serializeToJson());
         jsonobject.add("entity", this.entity.toJson(conditions));
         return jsonobject;
      }
   }
}
