package net.minecraft.advancements;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

public enum FrameType {
   TASK("task", 0, ChatFormatting.GREEN),
   CHALLENGE("challenge", 26, ChatFormatting.DARK_PURPLE),
   GOAL("goal", 52, ChatFormatting.GREEN);

   private final String name;
   private final int texture;
   private final ChatFormatting chatColor;
   private final Component displayName;

   private FrameType(String name, int texture, ChatFormatting chatColor) {
      this.name = name;
      this.texture = texture;
      this.chatColor = chatColor;
      this.displayName = Component.translatable("advancements.toast." + name);
   }

   public String getName() {
      return this.name;
   }

   public int getTexture() {
      return this.texture;
   }

   public static FrameType byName(String name) {
      for(FrameType frametype : values()) {
         if (frametype.name.equals(name)) {
            return frametype;
         }
      }

      throw new IllegalArgumentException("Unknown frame type '" + name + "'");
   }

   public ChatFormatting getChatColor() {
      return this.chatColor;
   }

   public Component getDisplayName() {
      return this.displayName;
   }
}
