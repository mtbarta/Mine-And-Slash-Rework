package net.minecraft.client.gui.font.glyphs;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.font.GlyphRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix4f;

@OnlyIn(Dist.CLIENT)
public class BakedGlyph {
   private final GlyphRenderTypes renderTypes;
   private final float u0;
   private final float u1;
   private final float v0;
   private final float v1;
   private final float left;
   private final float right;
   private final float up;
   private final float down;

   public BakedGlyph(GlyphRenderTypes renderTypes, float u0, float u1, float v0, float v1, float left, float right, float up, float down) {
      this.renderTypes = renderTypes;
      this.u0 = u0;
      this.u1 = u1;
      this.v0 = v0;
      this.v1 = v1;
      this.left = left;
      this.right = right;
      this.up = up;
      this.down = down;
   }

   public void render(boolean italic, float x, float y, Matrix4f matrix, VertexConsumer buffer, float red, float green, float blue, float alpha, int packedLight) {
      int i = 3;
      float f = x + this.left;
      float f1 = x + this.right;
      float f2 = this.up - 3.0F;
      float f3 = this.down - 3.0F;
      float f4 = y + f2;
      float f5 = y + f3;
      float f6 = italic ? 1.0F - 0.25F * f2 : 0.0F;
      float f7 = italic ? 1.0F - 0.25F * f3 : 0.0F;
      buffer.vertex(matrix, f + f6, f4, 0.0F).color(red, green, blue, alpha).uv(this.u0, this.v0).uv2(packedLight).endVertex();
      buffer.vertex(matrix, f + f7, f5, 0.0F).color(red, green, blue, alpha).uv(this.u0, this.v1).uv2(packedLight).endVertex();
      buffer.vertex(matrix, f1 + f7, f5, 0.0F).color(red, green, blue, alpha).uv(this.u1, this.v1).uv2(packedLight).endVertex();
      buffer.vertex(matrix, f1 + f6, f4, 0.0F).color(red, green, blue, alpha).uv(this.u1, this.v0).uv2(packedLight).endVertex();
   }

   public void renderEffect(BakedGlyph.Effect effect, Matrix4f matrix, VertexConsumer buffer, int packedLight) {
      buffer.vertex(matrix, effect.x0, effect.y0, effect.depth).color(effect.r, effect.g, effect.b, effect.a).uv(this.u0, this.v0).uv2(packedLight).endVertex();
      buffer.vertex(matrix, effect.x1, effect.y0, effect.depth).color(effect.r, effect.g, effect.b, effect.a).uv(this.u0, this.v1).uv2(packedLight).endVertex();
      buffer.vertex(matrix, effect.x1, effect.y1, effect.depth).color(effect.r, effect.g, effect.b, effect.a).uv(this.u1, this.v1).uv2(packedLight).endVertex();
      buffer.vertex(matrix, effect.x0, effect.y1, effect.depth).color(effect.r, effect.g, effect.b, effect.a).uv(this.u1, this.v0).uv2(packedLight).endVertex();
   }

   public RenderType renderType(Font.DisplayMode displayMode) {
      return this.renderTypes.select(displayMode);
   }

   @OnlyIn(Dist.CLIENT)
   public static class Effect {
      protected final float x0;
      protected final float y0;
      protected final float x1;
      protected final float y1;
      protected final float depth;
      protected final float r;
      protected final float g;
      protected final float b;
      protected final float a;

      public Effect(float x0, float y0, float x1, float y1, float depth, float r, float g, float b, float a) {
         this.x0 = x0;
         this.y0 = y0;
         this.x1 = x1;
         this.y1 = y1;
         this.depth = depth;
         this.r = r;
         this.g = g;
         this.b = b;
         this.a = a;
      }
   }
}
