package net.minecraft.client.gui.components;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class StateSwitchingButton extends AbstractWidget {
   protected ResourceLocation resourceLocation;
   protected boolean isStateTriggered;
   protected int xTexStart;
   protected int yTexStart;
   protected int xDiffTex;
   protected int yDiffTex;

   public StateSwitchingButton(int x, int y, int width, int height, boolean initialState) {
      super(x, y, width, height, CommonComponents.EMPTY);
      this.isStateTriggered = initialState;
   }

   public void initTextureValues(int xTexStart, int yTexStart, int xDiffTex, int yDiffTex, ResourceLocation resourceLocation) {
      this.xTexStart = xTexStart;
      this.yTexStart = yTexStart;
      this.xDiffTex = xDiffTex;
      this.yDiffTex = yDiffTex;
      this.resourceLocation = resourceLocation;
   }

   public void setStateTriggered(boolean triggered) {
      this.isStateTriggered = triggered;
   }

   public boolean isStateTriggered() {
      return this.isStateTriggered;
   }

   public void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {
      this.defaultButtonNarrationText(narrationElementOutput);
   }

   public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      RenderSystem.disableDepthTest();
      int i = this.xTexStart;
      int j = this.yTexStart;
      if (this.isStateTriggered) {
         i += this.xDiffTex;
      }

      if (this.isHoveredOrFocused()) {
         j += this.yDiffTex;
      }

      guiGraphics.blit(this.resourceLocation, this.getX(), this.getY(), i, j, this.width, this.height);
      RenderSystem.enableDepthTest();
   }
}
