package net.minecraft.client.gui.components.tabs;

import java.util.function.Consumer;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.layouts.FrameLayout;
import net.minecraft.client.gui.layouts.GridLayout;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GridLayoutTab implements Tab {
   private final Component title;
   protected final GridLayout layout = new GridLayout();

   public GridLayoutTab(Component title) {
      this.title = title;
   }

   public Component getTabTitle() {
      return this.title;
   }

   public void visitChildren(Consumer<AbstractWidget> consumer) {
      this.layout.visitWidgets(consumer);
   }

   public void doLayout(ScreenRectangle rectangle) {
      this.layout.arrangeElements();
      FrameLayout.alignInRectangle(this.layout, rectangle, 0.5F, 0.16666667F);
   }
}
