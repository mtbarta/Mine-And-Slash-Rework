package net.minecraft.client.gui.components;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ImageWidget extends AbstractWidget {
   private final ResourceLocation imageLocation;

   public ImageWidget(int width, int height, ResourceLocation imageLocation) {
      this(0, 0, width, height, imageLocation);
   }

   public ImageWidget(int x, int y, int width, int height, ResourceLocation imageLocation) {
      super(x, y, width, height, Component.empty());
      this.imageLocation = imageLocation;
   }

   protected void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {
   }

   public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      int i = this.getWidth();
      int j = this.getHeight();
      guiGraphics.blit(this.imageLocation, this.getX(), this.getY(), 0.0F, 0.0F, i, j, i, j);
   }
}
