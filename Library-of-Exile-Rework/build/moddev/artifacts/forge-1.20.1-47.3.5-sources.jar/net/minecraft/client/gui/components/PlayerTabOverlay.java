package net.minecraft.client.gui.components;

import com.mojang.authlib.GameProfile;
import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.Optionull;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentUtils;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.PlayerModelPart;
import net.minecraft.world.level.GameType;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.criteria.ObjectiveCriteria;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class PlayerTabOverlay {
   private static final Comparator<PlayerInfo> PLAYER_COMPARATOR = Comparator.<PlayerInfo>comparingInt((p_253306_) -> {
      return p_253306_.getGameMode() == GameType.SPECTATOR ? 1 : 0;
   }).thenComparing((p_269613_) -> {
      return Optionull.mapOrDefault(p_269613_.getTeam(), PlayerTeam::getName, "");
   }).thenComparing((p_253305_) -> {
      return p_253305_.getProfile().getName();
   }, String::compareToIgnoreCase);
   private static final ResourceLocation GUI_ICONS_LOCATION = new ResourceLocation("textures/gui/icons.png");
   public static final int MAX_ROWS_PER_COL = 20;
   public static final int HEART_EMPTY_CONTAINER = 16;
   public static final int HEART_EMPTY_CONTAINER_BLINKING = 25;
   public static final int HEART_FULL = 52;
   public static final int HEART_HALF_FULL = 61;
   public static final int HEART_GOLDEN_FULL = 160;
   public static final int HEART_GOLDEN_HALF_FULL = 169;
   public static final int HEART_GHOST_FULL = 70;
   public static final int HEART_GHOST_HALF_FULL = 79;
   private final Minecraft minecraft;
   private final Gui gui;
   @Nullable
   private Component footer;
   @Nullable
   private Component header;
   /**
    * Weither or not the playerlist is currently being rendered
    */
   private boolean visible;
   private final Map<UUID, PlayerTabOverlay.HealthState> healthStates = new Object2ObjectOpenHashMap<>();

   public PlayerTabOverlay(Minecraft minecraft, Gui gui) {
      this.minecraft = minecraft;
      this.gui = gui;
   }

   public Component getNameForDisplay(PlayerInfo playerInfo) {
      return playerInfo.getTabListDisplayName() != null ? this.decorateName(playerInfo, playerInfo.getTabListDisplayName().copy()) : this.decorateName(playerInfo, PlayerTeam.formatNameForTeam(playerInfo.getTeam(), Component.literal(playerInfo.getProfile().getName())));
   }

   private Component decorateName(PlayerInfo playerInfo, MutableComponent name) {
      return playerInfo.getGameMode() == GameType.SPECTATOR ? name.withStyle(ChatFormatting.ITALIC) : name;
   }

   /**
    * Called by GuiIngame to update the information stored in the playerlist, does not actually render the list, however.
    */
   public void setVisible(boolean visible) {
      if (this.visible != visible) {
         this.healthStates.clear();
         this.visible = visible;
         if (visible) {
            Component component = ComponentUtils.formatList(this.getPlayerInfos(), Component.literal(", "), this::getNameForDisplay);
            this.minecraft.getNarrator().sayNow(Component.translatable("multiplayer.player.list.narration", component));
         }
      }

   }

   private List<PlayerInfo> getPlayerInfos() {
      return this.minecraft.player.connection.getListedOnlinePlayers().stream().sorted(PLAYER_COMPARATOR).limit(80L).toList();
   }

   public void render(GuiGraphics guiGraphics, int width, Scoreboard scoreboard, @Nullable Objective objective) {
      List<PlayerInfo> list = this.getPlayerInfos();
      int i = 0;
      int j = 0;

      for(PlayerInfo playerinfo : list) {
         int k = this.minecraft.font.width(this.getNameForDisplay(playerinfo));
         i = Math.max(i, k);
         if (objective != null && objective.getRenderType() != ObjectiveCriteria.RenderType.HEARTS) {
            k = this.minecraft.font.width(" " + scoreboard.getOrCreatePlayerScore(playerinfo.getProfile().getName(), objective).getScore());
            j = Math.max(j, k);
         }
      }

      if (!this.healthStates.isEmpty()) {
         Set<UUID> set = list.stream().map((p_250472_) -> {
            return p_250472_.getProfile().getId();
         }).collect(Collectors.toSet());
         this.healthStates.keySet().removeIf((p_248583_) -> {
            return !set.contains(p_248583_);
         });
      }

      int i3 = list.size();
      int j3 = i3;

      int k3;
      for(k3 = 1; j3 > 20; j3 = (i3 + k3 - 1) / k3) {
         ++k3;
      }

      boolean flag = this.minecraft.isLocalServer() || this.minecraft.getConnection().getConnection().isEncrypted();
      int l;
      if (objective != null) {
         if (objective.getRenderType() == ObjectiveCriteria.RenderType.HEARTS) {
            l = 90;
         } else {
            l = j;
         }
      } else {
         l = 0;
      }

      int i1 = Math.min(k3 * ((flag ? 9 : 0) + i + l + 13), width - 50) / k3;
      int j1 = width / 2 - (i1 * k3 + (k3 - 1) * 5) / 2;
      int k1 = 10;
      int l1 = i1 * k3 + (k3 - 1) * 5;
      List<FormattedCharSequence> list1 = null;
      if (this.header != null) {
         list1 = this.minecraft.font.split(this.header, width - 50);

         for(FormattedCharSequence formattedcharsequence : list1) {
            l1 = Math.max(l1, this.minecraft.font.width(formattedcharsequence));
         }
      }

      List<FormattedCharSequence> list2 = null;
      if (this.footer != null) {
         list2 = this.minecraft.font.split(this.footer, width - 50);

         for(FormattedCharSequence formattedcharsequence1 : list2) {
            l1 = Math.max(l1, this.minecraft.font.width(formattedcharsequence1));
         }
      }

      if (list1 != null) {
         guiGraphics.fill(width / 2 - l1 / 2 - 1, k1 - 1, width / 2 + l1 / 2 + 1, k1 + list1.size() * 9, Integer.MIN_VALUE);

         for(FormattedCharSequence formattedcharsequence2 : list1) {
            int i2 = this.minecraft.font.width(formattedcharsequence2);
            guiGraphics.drawString(this.minecraft.font, formattedcharsequence2, width / 2 - i2 / 2, k1, -1);
            k1 += 9;
         }

         ++k1;
      }

      guiGraphics.fill(width / 2 - l1 / 2 - 1, k1 - 1, width / 2 + l1 / 2 + 1, k1 + j3 * 9, Integer.MIN_VALUE);
      int l3 = this.minecraft.options.getBackgroundColor(553648127);

      for(int i4 = 0; i4 < i3; ++i4) {
         int j4 = i4 / j3;
         int j2 = i4 % j3;
         int k2 = j1 + j4 * i1 + j4 * 5;
         int l2 = k1 + j2 * 9;
         guiGraphics.fill(k2, l2, k2 + i1, l2 + 8, l3);
         RenderSystem.enableBlend();
         if (i4 < list.size()) {
            PlayerInfo playerinfo1 = list.get(i4);
            GameProfile gameprofile = playerinfo1.getProfile();
            if (flag) {
               Player player = this.minecraft.level.getPlayerByUUID(gameprofile.getId());
               boolean flag1 = player != null && LivingEntityRenderer.isEntityUpsideDown(player);
               boolean flag2 = player != null && player.isModelPartShown(PlayerModelPart.HAT);
               PlayerFaceRenderer.draw(guiGraphics, playerinfo1.getSkinLocation(), k2, l2, 8, flag2, flag1);
               k2 += 9;
            }

            guiGraphics.drawString(this.minecraft.font, this.getNameForDisplay(playerinfo1), k2, l2, playerinfo1.getGameMode() == GameType.SPECTATOR ? -1862270977 : -1);
            if (objective != null && playerinfo1.getGameMode() != GameType.SPECTATOR) {
               int l4 = k2 + i + 1;
               int i5 = l4 + l;
               if (i5 - l4 > 5) {
                  this.renderTablistScore(objective, l2, gameprofile.getName(), l4, i5, gameprofile.getId(), guiGraphics);
               }
            }

            this.renderPingIcon(guiGraphics, i1, k2 - (flag ? 9 : 0), l2, playerinfo1);
         }
      }

      if (list2 != null) {
         k1 += j3 * 9 + 1;
         guiGraphics.fill(width / 2 - l1 / 2 - 1, k1 - 1, width / 2 + l1 / 2 + 1, k1 + list2.size() * 9, Integer.MIN_VALUE);

         for(FormattedCharSequence formattedcharsequence3 : list2) {
            int k4 = this.minecraft.font.width(formattedcharsequence3);
            guiGraphics.drawString(this.minecraft.font, formattedcharsequence3, width / 2 - k4 / 2, k1, -1);
            k1 += 9;
         }
      }

   }

   protected void renderPingIcon(GuiGraphics guiGraphics, int p_281809_, int p_282801_, int y, PlayerInfo playerInfo) {
      int i = 0;
      int j;
      if (playerInfo.getLatency() < 0) {
         j = 5;
      } else if (playerInfo.getLatency() < 150) {
         j = 0;
      } else if (playerInfo.getLatency() < 300) {
         j = 1;
      } else if (playerInfo.getLatency() < 600) {
         j = 2;
      } else if (playerInfo.getLatency() < 1000) {
         j = 3;
      } else {
         j = 4;
      }

      guiGraphics.pose().pushPose();
      guiGraphics.pose().translate(0.0F, 0.0F, 100.0F);
      guiGraphics.blit(GUI_ICONS_LOCATION, p_282801_ + p_281809_ - 11, y, 0, 176 + j * 8, 10, 8);
      guiGraphics.pose().popPose();
   }

   private void renderTablistScore(Objective objective, int y, String username, int p_283533_, int p_281254_, UUID playerUuid, GuiGraphics guiGraphics) {
      int i = objective.getScoreboard().getOrCreatePlayerScore(username, objective).getScore();
      if (objective.getRenderType() == ObjectiveCriteria.RenderType.HEARTS) {
         this.renderTablistHearts(y, p_283533_, p_281254_, playerUuid, guiGraphics, i);
      } else {
         String s = "" + ChatFormatting.YELLOW + i;
         guiGraphics.drawString(this.minecraft.font, s, p_281254_ - this.minecraft.font.width(s), y, 16777215);
      }
   }

   private void renderTablistHearts(int y, int p_283173_, int p_282149_, UUID playerUuid, GuiGraphics guiGraphics, int health) {
      PlayerTabOverlay.HealthState playertaboverlay$healthstate = this.healthStates.computeIfAbsent(playerUuid, (p_249546_) -> {
         return new PlayerTabOverlay.HealthState(health);
      });
      playertaboverlay$healthstate.update(health, (long)this.gui.getGuiTicks());
      int i = Mth.positiveCeilDiv(Math.max(health, playertaboverlay$healthstate.displayedValue()), 2);
      int j = Math.max(health, Math.max(playertaboverlay$healthstate.displayedValue(), 20)) / 2;
      boolean flag = playertaboverlay$healthstate.isBlinking((long)this.gui.getGuiTicks());
      if (i > 0) {
         int k = Mth.floor(Math.min((float)(p_282149_ - p_283173_ - 4) / (float)j, 9.0F));
         if (k <= 3) {
            float f = Mth.clamp((float)health / 20.0F, 0.0F, 1.0F);
            int i1 = (int)((1.0F - f) * 255.0F) << 16 | (int)(f * 255.0F) << 8;
            String s = "" + (float)health / 2.0F;
            if (p_282149_ - this.minecraft.font.width(s + "hp") >= p_283173_) {
               s = s + "hp";
            }

            guiGraphics.drawString(this.minecraft.font, s, (p_282149_ + p_283173_ - this.minecraft.font.width(s)) / 2, y, i1);
         } else {
            for(int l = i; l < j; ++l) {
               guiGraphics.blit(GUI_ICONS_LOCATION, p_283173_ + l * k, y, flag ? 25 : 16, 0, 9, 9);
            }

            for(int j1 = 0; j1 < i; ++j1) {
               guiGraphics.blit(GUI_ICONS_LOCATION, p_283173_ + j1 * k, y, flag ? 25 : 16, 0, 9, 9);
               if (flag) {
                  if (j1 * 2 + 1 < playertaboverlay$healthstate.displayedValue()) {
                     guiGraphics.blit(GUI_ICONS_LOCATION, p_283173_ + j1 * k, y, 70, 0, 9, 9);
                  }

                  if (j1 * 2 + 1 == playertaboverlay$healthstate.displayedValue()) {
                     guiGraphics.blit(GUI_ICONS_LOCATION, p_283173_ + j1 * k, y, 79, 0, 9, 9);
                  }
               }

               if (j1 * 2 + 1 < health) {
                  guiGraphics.blit(GUI_ICONS_LOCATION, p_283173_ + j1 * k, y, j1 >= 10 ? 160 : 52, 0, 9, 9);
               }

               if (j1 * 2 + 1 == health) {
                  guiGraphics.blit(GUI_ICONS_LOCATION, p_283173_ + j1 * k, y, j1 >= 10 ? 169 : 61, 0, 9, 9);
               }
            }

         }
      }
   }

   public void setFooter(@Nullable Component footer) {
      this.footer = footer;
   }

   public void setHeader(@Nullable Component header) {
      this.header = header;
   }

   public void reset() {
      this.header = null;
      this.footer = null;
   }

   @OnlyIn(Dist.CLIENT)
   static class HealthState {
      private static final long DISPLAY_UPDATE_DELAY = 20L;
      private static final long DECREASE_BLINK_DURATION = 20L;
      private static final long INCREASE_BLINK_DURATION = 10L;
      private int lastValue;
      private int displayedValue;
      private long lastUpdateTick;
      private long blinkUntilTick;

      public HealthState(int displayedValue) {
         this.displayedValue = displayedValue;
         this.lastValue = displayedValue;
      }

      public void update(int value, long guiTicks) {
         if (value != this.lastValue) {
            long i = value < this.lastValue ? 20L : 10L;
            this.blinkUntilTick = guiTicks + i;
            this.lastValue = value;
            this.lastUpdateTick = guiTicks;
         }

         if (guiTicks - this.lastUpdateTick > 20L) {
            this.displayedValue = value;
         }

      }

      public int displayedValue() {
         return this.displayedValue;
      }

      public boolean isBlinking(long guiTicks) {
         return this.blinkUntilTick > guiTicks && (this.blinkUntilTick - guiTicks) % 6L >= 3L;
      }
   }
}
